# Testes sugeridos (Godot 4.3 Compatibility / Android)

- [ ] Importação dos 12 GLBs sem erros no importador.
- [ ] Renderização do LV1 azul, LV2 vermelho, LV3 verde.
- [ ] Anéis rotacionam nos estados Q/W/E/R.
- [ ] Escudo aparece em combate e apresenta falha no estado quebrado.
- [ ] Beam vertical e partículas aparecem na evolução.
- [ ] Promover nível do LV1 para LV2 e LV2 para LV3 usando T.
- [ ] Avaliar FPS Android com HQ/LOD e partículas ligadas/desligadas.
- [ ] Conferir pivôs e dimensões no seu mapa existente.
- [ ] Ajustar Renderer/Glow para emissivos conforme hardware alvo.
