# Stellar Legacy — Relés de Clã 3D HQ

Pacote aditivo para **Godot 4.3 Compatibility (Android)**. Os modelos são novas interpretações procedurais tridimensionais baseadas na arte aprovada, não reconstruções idênticas de uma única imagem. **Nenhum modelo antigo foi substituído.**

## Conteúdo

- **3 GLB HQ:** `rele_lv1.glb`, `rele_lv2.glb`, `rele_lv3.glb`
- **3 GLB LOD:** `rele_lv1_lod.glb`, `rele_lv2_lod.glb`, `rele_lv3_lod.glb`
- **6 módulos:** `modulo_nucleo`, `modulo_anel`, `modulo_laser`, `modulo_missil`, `modulo_escudo`, `modulo_suporte` em GLB
- **3 cenas Godot:** `scenes/relays/rele_lv1.tscn` até `rele_lv3.tscn`
- **Controle:** `scripts/relays/relay_controller.gd`
- **Shaders:** `shaders/relays/relay_shield.gdshader`, `relay_beam.gdshader`
- **Demonstração:** `scenes/relays/demo_reles.tscn` + `scripts/relays/demo_reles.gd`

## Como instalar no Godot

1. Faça backup do projeto existente.
2. Copie as pastas `assets`, `scenes`, `scripts`, `shaders` do ZIP **para a raiz do projeto Godot**, mesclando pastas sem apagar as existentes.
3. Importe os `.glb` abrindo o projeto pelo editor e aguarde a indexação de recursos.
4. Execute a cena **`res://scenes/relays/demo_reles.tscn`** (F6) para conferir cores e animações.
5. Integre os relés ao mapa/combate instanciando as cenas correspondentes. As cenas não substituem seu `main.tscn`.

## Estados e integração

O script `relay_controller.gd` possui estados:
- `IDLE (0)` repouso: núcleo pulsante, rotação lenta e partículas leves
- `COMBAT (1)` combate: giro acelerado, luzes de alerta e campo de escudo
- `SHIELD_BROKEN (2)` escudo quebrado: flicker, faíscas e falhas de energia
- `EVOLVING (3)` evolução: rotor acelerado, feixe e partículas de ascensão

Exemplo GDScript:

```gdscript
var relay = load("res://scenes/relays/rele_lv2.tscn").instantiate()
add_child(relay)
relay.set_state(1) # combate
relay.set_state(2) # escudo quebrado
relay.recover_shield()
relay.promote_to_next_level() # ao fim da animação, LV2 -> LV3
```

Para dispositivos mais fracos, antes da cena entrar na árvore: `relay.use_mobile_lod = true` e `relay.enable_particles = false`.

## Limitações importantes

- **Os efeitos são feitos no Godot**, não animações embutidas nos GLBs.
- GLBs incluem modelos 3D de fato, materiais PBR e texturas leves incorporadas; o efeito de brilho/bloom depende da configuração do renderizador. Compatibilidade não oferece necessariamente o mesmo pós-processamento do Forward+.
- A geometria é autoral/procedural e reproduz a linguagem visual da prancha, não cada detalhe milimétrico.
- Shaders e cenas foram escritos para Godot 4.3, mas o ambiente de geração não contém o executável do editor. **Verifique na execução real antes de incorporar à branch principal.**
- Sem gameplay multiplayer/combate/rede nem salvamento adicionados; hooks de `set_state` são o ponto de integração.
