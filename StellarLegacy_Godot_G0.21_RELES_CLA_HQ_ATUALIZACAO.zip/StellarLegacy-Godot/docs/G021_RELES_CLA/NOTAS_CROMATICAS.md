# Identidade dos relés

- **LV1 azul elétrico:** núcleo e anéis ciano/azul; 4 braços com torres leves; arquitetura de início de clã.
- **LV2 vermelho rubi:** núcleo de contenção rubi, 6 braços e bancos de mísseis; fortaleza intermediária.
- **LV3 verde esmeralda e ouro:** 8 braços, defesas ampliadas, múltiplas torres secundárias e maior altura.

Acabamentos: cerâmica branco perolada, aço grafite, titânio escovado, rebites dourados e trilhas de energia emissivas. A referência visual completa permanece em `referencias/RELES_APROVADOS.png`.
