# Stellar Legacy Godot G0.22 — V3 & Cosmic Lighting

## Atualização sobre G0.21 HOTFIX imagens

### Naves V3 originais
- 13 GLBs V3 inseridos nos caminhos `assets/ships/SL_..._FINAL.glb`.
- Os 13 arquivos são byte a byte idênticos aos novos ZIPs recebidos. Não foram retopologizados, reempacotados nem tiveram as texturas modificadas.
- O helper `scripts/world/model_presentation.gd` ajusta somente a *escala do nó de exibição* para os novos tamanhos V3. As texturas e as malhas do GLB continuam intactas.
- Hangar, combate, equipamentos e loja compartilham este helper, com tamanhos específicos por vitrine.
- Stats, moeda, estoque, veículos bloqueados e preços permanecem inalterados.

### Oito armas HQ texturizadas
Os GLBs inseridos sem LOD ficam em `assets/weapons/`. O catálogo já tinha 5 armas vendáveis; os 3 conceitos extras ficam visíveis e **sem venda** até haver preço oficial.

| Equipamento do jogo | Molde visual HQ |
|---|---|
| ARC-1 | SL_ARMA_ARC_HQ |
| ARC-2 | SL_LASER_PULSE_HQ |
| ARC-3 | SL_LASER_BEAM_HQ |
| ARC-4 | SL_CANHAO_PLASMA_HQ |
| ARC-P1 | SL_LANCA_PARTICULAS_HQ |
| ARC-Q (apenas exposição) | SL_CANHAO_GAUSS_HQ |
| VORTEX-X (apenas exposição) | SL_CANHAO_ION_HQ |
| CATACLISMO (apenas exposição) | SL_DESINTEGRADOR_HQ |

Os vínculos de modelo são referências artísticas do cliente, não equivalências novas de dano, preço ou raridade.

### Minimapa
Exibe jogador, NPCs normais/evento, portais, relés, base e rota de navegação. **Não exibe minérios, box bônus ou box loot**, mesmo quando estão próximos. A coleta continua funcionando normalmente por aproximação ou toque no mundo 3D.

### Câmera e iluminação
- Câmera de voo um pouco mais elevada: deslocamento `(0, 33, 18)` e FOV 53°.
- Key/sun light acoplada à câmera: mesmo referencial de rotação durante todo o movimento; fill light azul mais suave.
- Iluminação de material e ambiente ajustada por BAIXO/MÉDIO/ALTO; **nenhuma mudança de GLB**.

### Cenários
- `scripts/world/sector_backdrop.gd` controla nebulosas no fundo, estrelas em camadas e poeira espacial com visibilidade conforme o perfil gráfico.
- 33 fundos gerados individualmente em `assets/backgrounds/sectors/`, cobrindo 1-1..3-8, 4-1..4-3, U-1..U-3 e A-AURORA/A-NEXUS/A-ECLIPSE.
- Elementos de cenário são não-colisíveis; não alteram a física, a movimentação nem a escala dos mapas 720×540.

### Vitrines
- Loja, hangar e equipamento compartilham a cenografia tridimensional `showcase_stage.gd`: nebula, estrutura metálica, anéis de luz e três luzes complementares para enxergar melhor as texturas.
- 21 previews texturizados renderizados diretamente dos arquivos V3/HQ em `assets/ui/g022_textured/`.
- Inspeção continua usando `PackedScene` direto do GLB HQ importado pelo Godot.

## Instalação no GitHub
1. Continue da G0.21 *com hotfix de imagens* instalada. Não use a G0.20 como base.
2. Suba somente **a parte 1** da G0.22, rode instalador, espere o workflow terminar.
3. Remova/substitua o zip na raiz e instale **a parte 2**; repita para cada parte subsequente.
4. Apenas após todas as partes, baixe o projeto ou abra no Godot Android.
5. A G0.22 deve ser validada pelo Godot 4.5.2 no workflow; a geração local não confirma compilação.
6. Os ZIPs incrementais **não podem ser instalados fora de ordem** nem todos juntos.

## QA sugerido
- Confirmar Aurora V3 no mapa e no hangar, e outra nave grande na vitrine.
- Verificar 8 armas 3D com texturas sem silhuetas genéricas.
- Conferir minimapa sem marcação de minério, bônus ou loot após coleta/spawn.
- Viajar por 1-X, 2-X, 3-X, 4-X, U-X, A-X e conferir fundos diferentes.
- Movimentar nave em todos os setores mantendo iluminação frontal.
- Alternar BAIXO/MÉDIO/ALTO: glbs imutáveis; poeira/efeitos variáveis.
- Abrir Loja/Hangar/Equipamentos para verificar vitrine/seleção, compras/salvamento e CONF 1/2.

Offline, sem alterações no Supabase, Render ou na versão web.
