# Stellar Legacy G0.22.1 — Recuperação cumulativa do instalador

O Actions falhou em `scripts/main.gd` porque faltava `res://scripts/world/model_presentation.gd`.
Causa: o ZIP da Parte 3 da G0.22 falhou antes de publicar seus arquivos; o hotfix visual seguinte só continha as alteracoes visuais, sem os componentes dos quais dependia.

Este ZIP **substitui a instalação separada da Parte 3 + hotfix visual**. Usa o estado final consolidado G0.22.1, incluindo:
- 8 GLBs de armas HQ e suas vinculações de loja/equipamentos;
- 33 fundos de setor e vitrine 3D;
- scripts `model_presentation.gd`, `sector_backdrop.gd`, `ship_display_scale.gd`, `showcase_stage.gd`, `weapon_art.gd`;
- `main.gd` e telas da G0.22.1 corrigidas (câmera, escala, cenário, minimapa).

Para instalar no GitHub pelo celular:
1. Deixe SOMENTE este arquivo .zip na raiz do repositório (remova ZIP antigo de atualização que tenha falhado).
2. GitHub > Actions > Stellar Legacy Godot - Instalador ZIP > Run workflow.
3. A importação deve passar pela etapa 'Importar e validar projeto Godot' e depois publicar no GitHub.
4. Não envie de novo as Partes 1 e 2 (assumindo que foram aprovadas).

Todas as informações econômicas, atributos de nave e itens continuam com o mesmo sistema do G0.22.1. Nenhum save do aparelho é alterado por este arquivo.

NOTA DE VALIDAÇÃO: conteúdo ZIP e caminhos res:// foram analisados estaticamente. A compilação verdadeira Godot 4.5.2 só será confirmada pela Action.
