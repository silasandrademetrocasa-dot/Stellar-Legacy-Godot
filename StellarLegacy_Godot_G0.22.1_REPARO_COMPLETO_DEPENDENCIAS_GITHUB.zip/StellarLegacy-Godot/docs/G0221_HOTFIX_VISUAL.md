# Stellar Legacy G0.22.1 — Hotfix Visual

**Base:** G0.22 (com relés da G0.21).

- Câmera tática: posição relativa de `(0,33,18)` para `(0,46,22)` e FOV 56.
- Nave jogável: alvo visual 3.35u em vez de 6.2u; GLB V3 intacto.
- Relés PvP: escala de apresentação por nível 0.66 / 0.59 / 0.50, sem mudar área de captura, atributos ou fases.
- 33 fundos espaciais com nebulosas mais visíveis, cores distintas e estrelas.
- Fundo da nebulosa principal reposicionado de y=-28 para y=-12; material emissivo adaptado à qualidade.
- Qualidade BAIXO: 75 estrelas próximas, sem camada distante/poeira, luzes simples.
- Qualidade MEDIO: 210 próximas + 110 profundas, menos luzes, sem poeira pesada.
- Qualidade ALTO: 430 próximas + 290 profundas + 92 partículas decorativas, maior iluminação.
- Modelos V3, armas, escudos, inventário, mapas e relés preservados.

O ajuste de tamanho vale para **gameplay**; o zoom e os GLBs da vitrine continuam como eram.
Não altera conexão online nem dados do Supabase.
