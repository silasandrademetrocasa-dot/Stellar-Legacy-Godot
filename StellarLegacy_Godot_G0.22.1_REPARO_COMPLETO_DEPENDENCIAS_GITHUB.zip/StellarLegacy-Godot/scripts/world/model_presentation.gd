extends RefCounted
## Non-destructive scene sizing for original textured GLBs. Fits 3D displays
## without rewriting mesh vertices, reducing polygons or changing materials.
static func fit_model(node: Node3D, target_span: float, center_to_origin: bool = true) -> float:
    if node == null:
        return 1.0
    var found: bool = false
    var low: Vector3 = Vector3.ZERO
    var high: Vector3 = Vector3.ZERO
    var stack: Array[Node] = [node]
    while not stack.is_empty():
        var current: Node = stack.pop_back()
        if current is MeshInstance3D:
            var mesh_inst: MeshInstance3D = current as MeshInstance3D
            if mesh_inst.mesh != null:
                var aabb: AABB = mesh_inst.get_aabb()
                for xx in [0.0, 1.0]:
                    for yy in [0.0, 1.0]:
                        for zz in [0.0, 1.0]:
                            var point: Vector3 = aabb.position + Vector3(aabb.size.x * xx, aabb.size.y * yy, aabb.size.z * zz)
                            var rel: Vector3 = node.to_local(mesh_inst.to_global(point))
                            if not found:
                                low = rel
                                high = rel
                                found = true
                            else:
                                low = low.min(rel)
                                high = high.max(rel)
        for child in current.get_children():
            if child is Node3D:
                stack.append(child)
    if not found:
        return 1.0
    var extent: Vector3 = high - low
    var widest: float = maxf(extent.x, extent.z)
    if widest < 0.005:
        widest = maxf(extent.y, 0.005)
    var factor: float = clampf(target_span / widest, 0.025, 4.0)
    node.scale = Vector3.ONE * factor
    if center_to_origin:
        node.position = -(low + high) * 0.5 * factor
    return factor
