extends RefCounted
## G0.22.1 — per-GLB real authored bounds, measured from unchanged V3 source.
## Only modifies the root Node3D display transform. Meshes and PBR materials remain intact.
## Actual gameplay physics / speed / detection / HP continue to use original values.
const VIEW_SPAN: Dictionary = {
    "AURORA": 3.05,
    "BASTION": 3.70,
    "BULWARK": 4.10,
    "KENSEI": 3.55,
    "LEVIATHAN": 4.10,
    "LYNX": 3.30,
    "MERIDIAN": 3.45,
    "PATHFINDER": 3.40,
    "PHANTOM": 3.35,
    "PIONEER": 3.25,
    "RAPTOR": 3.30,
    "SERAPH": 3.85,
    "VALKYRIE": 3.60,
}
const REAL_SPAN: Dictionary = {
    "AURORA": 18.400000,
    "BASTION": 32.400000,
    "BULWARK": 27.495000,
    "KENSEI": 18.657692,
    "LEVIATHAN": 26.698618,
    "LYNX": 21.599999,
    "MERIDIAN": 19.300000,
    "PATHFINDER": 24.100000,
    "PHANTOM": 23.700001,
    "PIONEER": 17.800000,
    "RAPTOR": 18.900000,
    "SERAPH": 24.600000,
    "VALKYRIE": 17.104225,
}
const REAL_CENTER: Dictionary = {
    "AURORA": Vector3(0.330612, 0.434654, -0.085981),
    "BASTION": Vector3(0.436000, 0.894093, -0.143363),
    "BULWARK": Vector3(-0.255761, 0.765108, -0.440625),
    "KENSEI": Vector3(0.000000, 0.496780, 0.523558),
    "LEVIATHAN": Vector3(0.000000, 0.686075, 0.785254),
    "LYNX": Vector3(0.000000, 0.415440, -0.087097),
    "MERIDIAN": Vector3(0.000000, 0.396202, -0.074231),
    "PATHFINDER": Vector3(0.000000, 0.483451, -0.084859),
    "PHANTOM": Vector3(0.000000, 0.526758, -0.085252),
    "PIONEER": Vector3(0.000000, 0.318071, -0.077391),
    "RAPTOR": Vector3(0.000000, 0.428176, -0.073256),
    "SERAPH": Vector3(0.000000, 0.907302, -0.080921),
    "VALKYRIE": Vector3(0.000000, 0.775678, 0.206573),
}
static func apply(node: Node3D, ship_id: String) -> void:
    if node == null:
        return
    var span: float = float(REAL_SPAN.get(ship_id, 18.0))
    var target: float = float(VIEW_SPAN.get(ship_id, 3.4))
    var factor: float = target / maxf(span, 0.01)
    # Imported GLB root is a Node3D; no geometry is rebuilt or decimated.
    node.scale = Vector3.ONE * factor
    var center: Vector3 = REAL_CENTER.get(ship_id, Vector3.ZERO)
    node.position = -center * factor
