extends RefCounted
## G0.22: shared physical showroom for store, hangar and equipment views.
## Lights and geometry are separate from the original textured PackedScene GLBs.
static func decorate(viewport: SubViewport, large: bool) -> void:
    var background := MeshInstance3D.new()
    background.name = "NebulosaDaVitrine"
    var quad := QuadMesh.new()
    quad.size = Vector2(43.0 if large else 31.0, 27.0 if large else 21.0)
    background.mesh = quad
    background.position = Vector3(0.0, 3.6, -19.0 if large else -15.0)
    var space_mat := StandardMaterial3D.new()
    space_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    space_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    space_mat.albedo_texture = load("res://assets/ui/g022_showcase_space.png") as Texture2D
    space_mat.emission_enabled = true
    space_mat.emission_texture = space_mat.albedo_texture
    space_mat.emission_energy_multiplier = 0.7
    background.material_override = space_mat
    viewport.add_child(background)
    for side in [-1, 1]:
        var column := MeshInstance3D.new()
        column.name = "Estrutura%d" % side
        var column_mesh := BoxMesh.new()
        column_mesh.size = Vector3(0.3, 10.0, 0.5)
        var metal := StandardMaterial3D.new()
        metal.albedo_color = Color(0.035, 0.10, 0.18)
        metal.metallic = 0.84
        column_mesh.material = metal
        column.mesh = column_mesh
        column.position = Vector3(float(side) * (7.9 if large else 5.6), 2.2, -6.5)
        viewport.add_child(column)
        var strip := MeshInstance3D.new()
        var strip_mesh := BoxMesh.new()
        strip_mesh.size = Vector3(0.065, 8.8, 0.22)
        var lit := StandardMaterial3D.new()
        lit.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        lit.albedo_color = Color(0.09, 0.82, 1.0) if side == -1 else Color(1.0, 0.49, 0.16)
        lit.emission_enabled = true
        lit.emission = lit.albedo_color
        strip_mesh.material = lit
        strip.mesh = strip_mesh
        strip.position = column.position + Vector3(0.0, 0.0, 0.32)
        viewport.add_child(strip)
    for i in range(3):
        var bulb := OmniLight3D.new()
        bulb.name = "Fill3D_%d" % i
        bulb.position = [Vector3(0.0, 5.0, 7.0), Vector3(-5.0, 1.0, 0.0), Vector3(5.0, 2.8, -2.0)][i]
        bulb.light_color = [Color(0.84, 0.93, 1.0), Color(0.18, 0.66, 1.0), Color(1.0, 0.65, 0.33)][i]
        bulb.light_energy = [1.25, 0.65, 0.52][i]
        bulb.omni_range = 24.0
        bulb.shadow_enabled = false
        viewport.add_child(bulb)
