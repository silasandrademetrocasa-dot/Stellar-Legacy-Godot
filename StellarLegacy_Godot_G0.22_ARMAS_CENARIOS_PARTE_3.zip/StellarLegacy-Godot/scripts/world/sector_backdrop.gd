extends Node3D
## G0.22: sky layers, nebulae and dust unique per sector. World content is scenery,
## not collidable. Shading/particle counts change by quality, never ship GLBs.
const Routes = preload("res://scripts/world_routes.gd")
var backdrop: MeshInstance3D
var distant: MeshInstance3D
var nearby_stars: MultiMeshInstance3D
var deep_stars: MultiMeshInstance3D
var dust: MultiMeshInstance3D
var active_map: String = ""
var quality: String = "MEDIO"

func _ready() -> void:
    backdrop = _plane("NebulosaSetor", 1130.0, 870.0, -28.0, 1.0)
    distant = _plane("NebulosaDistante", 1570.0, 1220.0, -72.0, 0.36)
    nearby_stars = _scatter("EstrelasProximas", 420, -11.0, 0.105, false)
    deep_stars = _scatter("EstrelasProfundas", 320, -52.0, 0.16, false)
    dust = _scatter("PoeiraEspacial", 105, -8.0, 0.62, true)

func _plane(title: String, width: float, length: float, y: float, alpha: float) -> MeshInstance3D:
    var obj := MeshInstance3D.new()
    obj.name = title
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(width, length)
    obj.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(1.0, 1.0, 1.0, alpha)
    obj.material_override = mat
    obj.position.y = y
    add_child(obj)
    return obj

func _scatter(title: String, count: int, elevation: float, base_radius: float, is_dust: bool) -> MultiMeshInstance3D:
    var dot := SphereMesh.new()
    dot.radius = base_radius
    dot.height = base_radius * 2.0
    dot.radial_segments = 6
    dot.rings = 3
    var paint := StandardMaterial3D.new()
    paint.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    paint.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    paint.albedo_color = Color(0.54, 0.77, 1.0, 0.32 if is_dust else 0.93)
    paint.vertex_color_use_as_albedo = true
    dot.material = paint
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = true
    multi.mesh = dot
    multi.instance_count = count
    var out := MultiMeshInstance3D.new()
    out.name = title
    out.multimesh = multi
    add_child(out)
    return out

func set_sector(map_id: String, graphics: String) -> void:
    active_map = map_id
    var tex_path: String = "res://assets/backgrounds/sectors/%s.png" % map_id.replace("-", "_")
    if not ResourceLoader.exists(tex_path):
        tex_path = "res://assets/backgrounds/sectors/1_1.png"
    var tex: Texture2D = load(tex_path) as Texture2D
    if tex != null:
        for obj in [backdrop, distant]:
            var mat: StandardMaterial3D = obj.material_override as StandardMaterial3D
            mat.albedo_texture = tex
            mat.emission_enabled = true
            mat.emission_texture = tex
            mat.emission_energy_multiplier = 0.28 if obj == backdrop else 0.12
    var seed_value: int = map_id.hash()
    var rng := RandomNumberGenerator.new()
    rng.seed = absi(seed_value) + 2022
    var tint: Color = Color(0.37, 0.68, 1.0)
    if map_id.begins_with("2-"):
        tint = Color(1.0, 0.40, 0.40)
    elif map_id.begins_with("3-"):
        tint = Color(0.24, 1.0, 0.74)
    elif map_id.begins_with("4-"):
        tint = Color(0.79, 0.50, 1.0)
    elif map_id.begins_with("U-"):
        tint = Color(0.53, 0.79, 1.0)
    elif map_id.begins_with("A-"):
        tint = Routes.ASTRAL_COLORS.get(map_id, Color(0.40, 0.75, 1.0))
    _reseat(nearby_stars, rng, -11.0, tint, false)
    _reseat(deep_stars, rng, -52.0, tint, false)
    _reseat(dust, rng, -8.0, tint, true)
    set_quality(graphics)

func _reseat(group: MultiMeshInstance3D, rng: RandomNumberGenerator, layer_y: float, tint: Color, is_dust: bool) -> void:
    var mm: MultiMesh = group.multimesh
    for i in range(mm.instance_count):
        var place := Vector3(rng.randf_range(-515.0, 515.0), layer_y + rng.randf_range(-5.0, 5.0), rng.randf_range(-395.0, 395.0))
        var scale_value: float = rng.randf_range(0.40, 1.75) if not is_dust else rng.randf_range(0.85, 3.2)
        mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3.ONE * scale_value), place))
        var color: Color = Color.WHITE.lerp(tint, rng.randf_range(0.18, 0.82))
        color.a = rng.randf_range(0.13, 0.28) if is_dust else rng.randf_range(0.52, 1.0)
        mm.set_instance_color(i, color)

func set_quality(profile: String) -> void:
    quality = profile
    if backdrop == null:
        return
    backdrop.visible = true
    distant.visible = profile != "BAIXO"
    nearby_stars.visible = true
    deep_stars.visible = profile != "BAIXO"
    dust.visible = profile == "ALTO"
